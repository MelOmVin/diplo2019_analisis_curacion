<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tft.apply_vocab" />
<meta itemprop="path" content="Stable" />
</div>

# tft.apply_vocab

``` python
tft.apply_vocab(
    x,
    deferred_vocab_filename_tensor,
    default_value=-1,
    num_oov_buckets=0,
    lookup_fn=None,
    name=None
)
```

See <a href="../tft/apply_vocabulary.md"><code>tft.apply_vocabulary</code></a>. (deprecated)

Warning: THIS FUNCTION IS DEPRECATED. It will be removed in a future version.
Instructions for updating:
Use `tft.apply_vocabulary()` instead.
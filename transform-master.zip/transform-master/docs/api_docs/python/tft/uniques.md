<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tft.uniques" />
<meta itemprop="path" content="Stable" />
</div>

# tft.uniques

``` python
tft.uniques(
    x,
    top_k=None,
    frequency_threshold=None,
    vocab_filename=None,
    store_frequency=False,
    weights=None,
    labels=None,
    name=None
)
```

See <a href="../tft/vocabulary.md"><code>tft.vocabulary</code></a>. (deprecated)

Warning: THIS FUNCTION IS DEPRECATED. It will be removed in a future version.
Instructions for updating:
Use `tft.vocabulary()` instead.
<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tft_beam.analyzer_cache.validate_dataset_keys" />
<meta itemprop="path" content="Stable" />
</div>

# tft_beam.analyzer_cache.validate_dataset_keys

``` python
tft_beam.analyzer_cache.validate_dataset_keys(keys)
```


<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tft_beam.info_theory.math" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tft_beam.info_theory.math



This is an alias for a Python built-in.

This module is always available.  It provides access to the
mathematical functions defined by the C standard.

